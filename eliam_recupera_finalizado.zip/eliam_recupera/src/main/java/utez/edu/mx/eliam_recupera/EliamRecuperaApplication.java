package utez.edu.mx.eliam_recupera;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EliamRecuperaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EliamRecuperaApplication.class, args);
	}

}
